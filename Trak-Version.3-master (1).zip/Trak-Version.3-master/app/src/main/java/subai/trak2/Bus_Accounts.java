package subai.trak2;

/**
 * Created by dcs-madl11 on 10/25/17.
 */

public class Bus_Accounts {
    public String accommodation;
    public String busCompany;


    public Bus_Accounts(String accommodation, String bus_company){
        this.accommodation = accommodation;
        this.busCompany = bus_company;
    }
}
